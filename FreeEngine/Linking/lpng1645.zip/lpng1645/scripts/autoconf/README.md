Autoconf Macro Files for the PNG Reference Library
==================================================

The Autoconf files associated with libpng are free software.
Use, modification and distribution of each individual file
are subject to the specific licensing terms and conditions
stated at the top of the file.
